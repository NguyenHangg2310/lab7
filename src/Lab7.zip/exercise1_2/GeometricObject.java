package exercise1_2;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();
}
