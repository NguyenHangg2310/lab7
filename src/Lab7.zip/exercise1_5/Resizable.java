package exercise1_5;

public interface Resizable {
    void resize(int percent);
}
